This directory contains a list of examples that have not been vetted to the extent the other examples have.
They will be eventually be moved out of this WIP dir.
The java doc in each example should indicate what the known issues are with each example.  

Contributions are welcome. Debugging and getting these examples going might be an easy way to start contributing!