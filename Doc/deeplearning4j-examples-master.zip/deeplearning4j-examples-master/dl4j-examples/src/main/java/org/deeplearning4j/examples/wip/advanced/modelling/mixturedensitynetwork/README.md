Issue Summary: Unsure if it actually does what it says it does
Action Items: Needs to be reviewed
Github Issue: https://github.com/eclipse/deeplearning4j-examples/issues/977
