Issue Summary: Great example but it errors out currently.
Action Items: Get it to run :)
Github Issue: https://github.com/eclipse/deeplearning4j-examples/issues/971
