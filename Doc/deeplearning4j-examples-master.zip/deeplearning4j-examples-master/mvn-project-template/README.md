# Sample Template Project
Use this as a minimal starting point for your own projects.
